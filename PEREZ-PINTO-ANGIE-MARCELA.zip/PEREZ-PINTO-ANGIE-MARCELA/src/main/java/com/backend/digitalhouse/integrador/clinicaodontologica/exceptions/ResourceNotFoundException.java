package com.backend.digitalhouse.integrador.clinicaodontologica.exceptions;

public class ResourceNotFoundException extends Exception{
    public ResourceNotFoundException(String message) {

        super("Aqui va el mensaje del problema");
    }
}

